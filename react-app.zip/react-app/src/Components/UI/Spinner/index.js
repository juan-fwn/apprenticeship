import Spinner from "./Spinner";

export default Spinner;
