import Movie from "./Movie";

export default Movie;
