import MovieList from "./MovieList";

export default MovieList;
