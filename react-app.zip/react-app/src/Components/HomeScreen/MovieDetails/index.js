import MovieDetails from "./MovieDetails";

export default MovieDetails;
