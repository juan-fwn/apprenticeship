import TrailerSection from "./TrailerSection";

export default TrailerSection;
